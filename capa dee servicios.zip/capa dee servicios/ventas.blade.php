<html>
<head>
<title>locales</title>
</head>

<body>
<p><b>Bienvenido</b></p>
<style type="text/css">
    #cuadrado {
     width: 100px; 
     height: 100px; 
     border: 3px solid #555;
     background: #008F39;
}
      </style>
      <style type="text/css">
     #cuadrado1 {
     width: 100px; 
     height: 100px; 
     border: 3px solid #555;
     background: #F8F32B;
}
      </style>
      
      <style type="text/css">
      #cuadrado2 {
     width: 100px; 
     height: 100px; 
     border: 3px solid #555;
     background: #FF0000;
}
      </style>
<div>
    @if ($ventas>6000)
    <ul id="cuadrado">
        <p ><?echo $ventas?>  </p>
        </ul>
    
     @elseif($ventas< 2000)
      <ul id="cuadrado2">
        <p ><?echo $ventas?>  </p>
        </ul> 
        @elseif($ventas>2000|| $ventas< 8000 )
      <ul id="cuadrado1">
        <p ><?echo $ventas?>  </p>
        </ul>  
    @endif

</body>

</html>