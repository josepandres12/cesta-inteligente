<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\product;

class proyecto extends Controller
{
    //es para get para select 
    public function index()
    {
        return proyecto::all();//para selecrt
    }
    //busqueda por clave primaria y se utiliza solo para id de la base, si quiere con otro registro es con where
    public function show($id)// para id o otro segristo se usar show
    {
        //select * from venta where ID=$id (solo clave primaria )
        return proyecto::find($id);
        //select * from venta where ciudad= $param
       // return venta::where('ciudad' $param);
    }
    //es para el post o insertar datos
    public function store(Request $request)
    {
        return proyecto::create($request->all());
    }
        //hacer update o actualizacion de datos
    public function update(Request $request, $id)
    {
        $ventas=proyecto::findOrFail($id);
        $ventas->update($resquest->all());
        return $ventas;
    }
    //delete op eleiminar datos
    public function delete($id)
    {
        $ventas=proyecto::findOrFail($id);
        $ventas->delete();
        return 204;//codigo para borrar datos 
    }
}
