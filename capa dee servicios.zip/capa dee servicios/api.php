<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
//la ruta se llama htpp://miservidor/api/venta
Route::get('proyecto','proyecto@index');
//para paso de de datos y insertar
Route::get('proyecto/{id}','proyecto@show');
//actualizar datos
Route::post('proyecto','proyecto@store');
Route::put('proyecto/{id}','proyecto@update');
Route::delete('proyecto/{id}','proyecto@delete');
